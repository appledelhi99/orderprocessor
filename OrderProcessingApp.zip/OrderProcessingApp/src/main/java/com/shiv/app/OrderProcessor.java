package com.shiv.app;

import java.util.Scanner;

import com.shiv.domain.Product;
import com.shiv.domain.impl.Book;
import com.shiv.domain.impl.Membership;
import com.shiv.domain.impl.Other;
import com.shiv.domain.impl.Upgrade;
import com.shiv.domain.impl.Video;

public class OrderProcessor {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String[] input = new String[2];
		String type;
		String name = null;
		System.out.println(
				"Enter Product type (video, membership, upgrade, book, other) and name (if applicable) seperated by space");
		input = sc.nextLine().split(" ");
		if(input.length==2) {
			if (input[1] != null) {
				name = input[1];
			} else {
				name = "";
			}
		}
		type = input[0];
		
		Product product;
		switch (type.toLowerCase()) {
		case "membership": {
			product = new Membership();
			break;
		}
		case "upgrade": {
			product = new Upgrade();
			break;
		}
		case "video": {
			if (name == null) {
				alertToEnterName();
				break;
			} else {
				product = new Video(name);
				break;
			}
		}

		case "book": {
			if (name == null) {
				alertToEnterName();
				break;

			} else {
				product = new Book(name);
				break;
			}
		}

		default: {
			if (name == null) {
				alertToEnterName();
				break;
			}
			product = new Other(name);
			break;
		}
		}
		sc.close();
	}

	static void alertToEnterName() {

		System.out.println("please enter valid name");

	}

}