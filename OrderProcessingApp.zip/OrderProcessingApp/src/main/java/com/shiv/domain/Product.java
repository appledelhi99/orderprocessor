package com.shiv.domain;

import java.util.List;

public abstract class Product {
	
	public String itemName;
	public List<String> Operations;
	public abstract void GetSlip();
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public List<String> getOperations() {
		return Operations;
	}
	public void setOperations(List<String> operations) {
		Operations = operations;
	}
	
}
