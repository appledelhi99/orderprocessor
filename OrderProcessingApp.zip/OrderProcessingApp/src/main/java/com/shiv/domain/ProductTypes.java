package com.shiv.domain;
  public enum ProductTypes
      {
          Video,
          Membership,
          Upgrade,
          Book,
          Other
      }