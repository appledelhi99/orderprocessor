package com.shiv.domain.impl;

import java.util.ArrayList;

public class Book extends PhysicalProduct {
	public Book(String itemName)
	 {
         this.itemName = itemName;
         Operations = new ArrayList<String>();
         super.GetSlip();
         super.AddCommission();
         GetSlip();
     }
     public  void GetSlip()
     {
         Operations.add("Create a duplicate packing slip for the royalty department.");
         System.out.println("Create a duplicate packing slip for the royalty department.");
     }
}
