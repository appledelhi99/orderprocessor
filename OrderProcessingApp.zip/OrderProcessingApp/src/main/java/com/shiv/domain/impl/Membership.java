package com.shiv.domain.impl;

import java.util.ArrayList;

public class Membership extends NonPhysicalProduct {
	
	public Membership()
    {
        Operations = new ArrayList<String>();
        super.GetSlip();
        Operations.add("Activate that membership");
        System.out.println("Activate that membership");
        super.DropMail();
    }

}
