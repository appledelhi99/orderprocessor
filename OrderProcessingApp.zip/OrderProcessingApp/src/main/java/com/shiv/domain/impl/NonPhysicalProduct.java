package com.shiv.domain.impl;

import com.shiv.domain.Product;

public abstract class NonPhysicalProduct extends Product{
	
	 public  void GetSlip()
     {
         Operations.add("Generated a packing slip.");
         System.out.println("Generated a packing slip.");

     }
     public  void DropMail()
     {
         Operations.add("Mail Sent");         
         System.out.println("Mail Sent");

     }

}
