package com.shiv.domain.impl;

import java.util.ArrayList;

public class Other extends PhysicalProduct {
	 public Other(String name)
     {
         this.itemName = name;
         Operations = new ArrayList<String>();
         super.GetSlip();
         super.AddCommission();
     }
}
