package com.shiv.domain.impl;

import com.shiv.domain.Product;

public abstract class PhysicalProduct extends Product {
	
	 public  void GetSlip()
     {
         Operations.add("Generated a packing slip for shipping.");
         System.out.println("Generated a packing slip for shipping.");
     }
	 
	 public  void AddCommission()
     {
         Operations.add("Commission payment to the agent");
         System.out.println("Commission payment to the agent");

     }

}
