package com.shiv.domain.impl;

import java.util.ArrayList;

public class Upgrade extends NonPhysicalProduct {
	 public Upgrade()
     {
         Operations = new ArrayList<String>();
         super.GetSlip();
         Operations.add("Apply the upgrade");
         System.out.println("Apply the upgrade");
         super.DropMail();
     }
}
