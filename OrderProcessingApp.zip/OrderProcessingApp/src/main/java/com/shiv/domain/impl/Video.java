package com.shiv.domain.impl;

import java.util.ArrayList;

public class Video extends NonPhysicalProduct{
	
	 public Video(String videoName)
     {
         Operations = new ArrayList<String>();
         itemName = videoName;

         GetSlip();
     }
     public  void GetSlip()
     {
         super.GetSlip();
         if (itemName.equalsIgnoreCase("learning to ski"))
         {
             Operations.add("'First Aid' video added to the packing slip");
             System.out.println("'First Aid' video added to the packing slip");

         }
     }

}
